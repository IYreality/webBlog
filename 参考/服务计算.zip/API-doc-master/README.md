# API-doc



小组成员:

GostBop 黄灿铭 16340079 [【服务计算】简单 web 服务与客户端开发实战](https://blog.csdn.net/hcm_0079/article/details/85072030) [【服务计算】应用容器化](https://blog.csdn.net/hcm_0079/article/details/85241385)

7cthunder 黄俊凯 16340082 [Swagger & Mock](https://7cthunder.github.io/2018/12/16/%E6%9C%8D%E5%8A%A1%E8%AE%A1%E7%AE%97-Swagger-Mock/)

9ayhub 何坤宁 16340073 [【服务计算】| 简单 web 服务与客户端开发实战---项目小结](https://blog.csdn.net/cat_xing/article/details/85040543)

skywalker00001 侯翼 16340075 [服务计算--Simple Blog项目总结](https://blog.csdn.net/Skywalker1111/article/details/85042595)
