# install
go get -v github.com/GostBops/Server

# run
go run main.go
